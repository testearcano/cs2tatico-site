export default function Home() {
  return <div className="p-10 text-3xl">CS2Tatico - Home Page</div>;
}