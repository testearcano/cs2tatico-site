# CS2Tatico - Site

Template Next.js + Tailwind para o projeto CS2Tatico.

## Como usar

1. Importar para Replit ou clonar o repositório.
2. Rodar: `npm install` (no Replit já roda automaticamente).
3. Executar: `npm run dev` e abrir o preview na porta 3000.

Feito para facilitar a edição pelo usuário — Lucas.
