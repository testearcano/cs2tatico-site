import Link from 'next/link'

export default function Navbar(){
  const links = [
    ['/', 'Início'],
    ['/crosshair','Miras'],
    ['/smokes','Smokes'],
    ['/skins','Skins'],
    ['/kits','Kits'],
    ['/campeonatos','Campeonatos'],
    ['/tools','Tools']
  ]
  return (
    <nav className="w-full bg-black/40 backdrop-blur-sm border-b border-white/5 p-4">
      <div className="max-w-6xl mx-auto flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-violet-600 rounded flex items-center justify-center font-bold">CS2</div>
          <div className="text-xl font-bold">CS2Tatico</div>
        </div>
        <div className="flex gap-4">
          {links.map(l=> (
            <Link key={l[0]} href={l[0]} className="hover:text-yellow-400">{l[1]}</Link>
          ))}
        </div>
      </div>
    </nav>
  )
}
