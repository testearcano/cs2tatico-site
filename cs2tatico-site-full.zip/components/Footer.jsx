export default function Footer(){
  return (
    <footer className="mt-8 p-6 text-center text-sm text-gray-400">
      CS2Tatico • Feito para Lucas • © {new Date().getFullYear()}
    </footer>
  )
}
