export default function SkinCard({ skin }){
  return (
    <div className="p-3 bg-neutral-900/50 rounded">
      <div className="h-36 bg-neutral-800 rounded flex items-center justify-center">Imagem</div>
      <h4 className="mt-3 font-semibold">{skin.name}</h4>
      <p className="text-sm text-gray-300">R$ {skin.price.toFixed(2)} · {skin.rarity}</p>
      <div className="mt-2 flex gap-2">
        <button className="px-2 py-1 bg-violet-600 rounded text-sm">Comparar</button>
        <button className="px-2 py-1 bg-gray-800 rounded text-sm">Ver no mercado</button>
      </div>
    </div>
  )
}
