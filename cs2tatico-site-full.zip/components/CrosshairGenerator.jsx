'use client'
import { useRef, useEffect, useState } from 'react'

export default function CrosshairGenerator(){
  const canvasRef = useRef(null)
  const [color,setColor] = useState('#ffffff')
  const [size,setSize] = useState(6)
  const [gap,setGap] = useState(-2)
  const [thickness,setThickness] = useState(2)

  useEffect(()=>{
    const c = canvasRef.current
    if(!c) return
    const ctx = c.getContext('2d')
    const w = c.width = 320
    const h = c.height = 180
    ctx.clearRect(0,0,w,h)
    const cx = w/2
    const cy = h/2
    ctx.fillStyle = color
    ctx.fillRect(cx - thickness/2, cy + gap - size - thickness, thickness, size)
    ctx.fillRect(cx - thickness/2, cy - gap + thickness, thickness, size)
    ctx.fillRect(cx + gap - size - thickness, cy - thickness/2, size, thickness)
    ctx.fillRect(cx - gap + thickness, cy - thickness/2, size, thickness)
  },[color,size,gap,thickness])

  function generateCFG(){
    return `cl_crosshaircolor "${color}"\ncl_crosshairsize "${size}"\ncl_crosshairthickness "${thickness}"\ncl_crosshairgap "${gap}"`
  }

  return (
    <div className="grid md:grid-cols-2 gap-4">
      <div className="p-4 bg-neutral-900 rounded">
        <label className="block text-sm">Cor</label>
        <input type="color" value={color} onChange={e=>setColor(e.target.value)} />
        <label className="block mt-3 text-sm">Tamanho: {size}</label>
        <input type="range" min="1" max="30" value={size} onChange={e=>setSize(Number(e.target.value))} />
        <label className="block mt-3 text-sm">Gap: {gap}</label>
        <input type="range" min={-30} max={30} value={gap} onChange={e=>setGap(Number(e.target.value))} />
        <label className="block mt-3 text-sm">Thickness: {thickness}</label>
        <input type="range" min="1" max="10" value={thickness} onChange={e=>setThickness(Number(e.target.value))} />
        <pre className="mt-3 bg-black/40 p-2 rounded text-sm">{generateCFG()}</pre>
        <button className="mt-2 px-3 py-1 bg-violet-600 rounded" onClick={()=>navigator.clipboard.writeText(generateCFG())}>Copiar CFG</button>
      </div>
      <div className="p-4 bg-neutral-900 rounded flex items-center justify-center">
        <canvas ref={canvasRef} width={320} height={180} className="border border-white/10 rounded" />
      </div>
    </div>
  )
}
