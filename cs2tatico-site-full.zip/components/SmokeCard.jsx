export default function SmokeCard({ smoke }){
  return (
    <div className="p-3 bg-neutral-900/50 rounded">
      <h4 className="font-semibold">{smoke.title}</h4>
      <p className="text-xs text-gray-400">{smoke.map} · {smoke.side} · {smoke.type}</p>
      <div className="mt-3 flex gap-2">
        <button className="px-2 py-1 bg-violet-600 rounded text-sm">Ver</button>
        <button className="px-2 py-1 bg-gray-800 rounded text-sm">Copiar</button>
      </div>
    </div>
  )
}
