export default function Home() {
  return (
    <section>
      <h1 className="text-4xl font-extrabold mb-3">CS2Tatico</h1>
      <p className="text-lg text-gray-300 mb-6">Seu hub de utilitários, smokes, miras e skins para CS2.</p>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 rounded bg-neutral-900/50">
          <h3 className="font-bold">Notícias rápidas</h3>
          <p className="text-sm text-gray-300 mt-2">Patch notes, novidades e atualizações.</p>
        </div>
        <div className="p-4 rounded bg-neutral-900/50">
          <h3 className="font-bold">Destaques</h3>
          <p className="text-sm text-gray-300 mt-2">Smokes e miras da semana.</p>
        </div>
        <div className="p-4 rounded bg-neutral-900/50">
          <h3 className="font-bold">Próximos campeonatos</h3>
          <p className="text-sm text-gray-300 mt-2">Calendário e transmissões.</p>
        </div>
      </div>
    </section>
  )
}
