import Navbar from '../components/Navbar'
import Footer from '../components/Footer'
import './globals.css'

export const metadata = { title: 'CS2Tatico' }

export default function RootLayout({ children }) {
  return (
    <html lang="pt-br">
      <body>
        <Navbar />
        <main className="min-h-[70vh] p-6 max-w-6xl mx-auto">{children}</main>
        <Footer />
      </body>
    </html>
  )
}
