import dynamic from 'next/dynamic'
const CrosshairGenerator = dynamic(()=>import('../../components/CrosshairGenerator'), { ssr: false })

export default function Crosshair() {
  return (
    <section>
      <h1 className="text-3xl font-bold mb-3">Miras</h1>
      <p className="text-gray-300 mb-6">Gerador interativo — ajuste e copie sua configuração.</p>
      <CrosshairGenerator />
    </section>
  )
}
