export default function Tools(){
  return (
    <section>
      <h1 className="text-3xl font-bold mb-3">Ferramentas</h1>
      <p className="text-gray-300">Calculadoras de sens, conversores e configs.</p>
    </section>
  )
}
