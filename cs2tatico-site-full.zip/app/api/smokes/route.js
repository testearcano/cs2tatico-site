export async function GET(request){
  const data = [
    { id:1, map:'Mirage', side:'TR', type:'smoke', title:'Window smoke - A' },
    { id:2, map:'Inferno', side:'TR', type:'smoke', title:'Balcony smoke - B' }
  ]
  return new Response(JSON.stringify(data), { status:200 })
}
