export async function GET(request){
  const data = [
    { id:'ak_redline', name:'AK-47 | Redline', price:45.0, rarity:'Covert' },
    { id:'m4a1_sg', name:'M4A1-S | Guardian', price:20.0, rarity:'Classified' }
  ]
  return new Response(JSON.stringify(data), { status:200 })
}
