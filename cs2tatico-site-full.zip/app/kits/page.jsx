export default function Kits(){
  return (
    <section>
      <h1 className="text-3xl font-bold mb-3">Kits</h1>
      <p className="text-gray-300">Kits temáticos prontos para copiar ou ver no mercado.</p>
    </section>
  )
}
