export default function Campeonatos(){
  const events = [
    { id:1, name:'IEM Example Cup', from:'2025-12-05', to:'2025-12-14', prize:'$250,000' }
  ]
  return (
    <section>
      <h1 className="text-3xl font-bold mb-3">Campeonatos</h1>
      <div className="grid gap-4">
        {events.map(e=> (
          <div key={e.id} className="p-3 bg-neutral-900/50 rounded">
            <h3 className="font-semibold">{e.name}</h3>
            <p className="text-sm text-gray-300">{e.from} → {e.to} • Premiação: {e.prize}</p>
          </div>
        ))}
      </div>
    </section>
  )
}
