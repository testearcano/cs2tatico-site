import SkinCard from '../../components/SkinCard'

export default function Skins(){
  const skins = [
    { id:'ak_redline', name:'AK-47 | Redline', price:45.0, rarity:'Covert' },
    { id:'m4a1_sg', name:'M4A1-S | Guardian', price:20.0, rarity:'Classified' }
  ]

  return (
    <section>
      <h1 className="text-3xl font-bold mb-3">Skins</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {skins.map(s=> <SkinCard key={s.id} skin={s} />)}
      </div>
    </section>
  )
}
