import SmokeCard from '../../components/SmokeCard'

export default async function Smokes() {
  // no futuro: fetch('/api/smokes')
  const data = [
    { id:1, map:'Mirage', side:'TR', type:'smoke', title:'Window smoke - A' },
    { id:2, map:'Inferno', side:'TR', type:'smoke', title:'Balcony smoke - B' }
  ]

  return (
    <section>
      <h1 className="text-3xl font-bold mb-3">Smokes</h1>
      <p className="text-gray-300 mb-6">Filtros por mapa, lado e tipo — adicione seus próprios lineups.</p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {data.map(s=> <SmokeCard key={s.id} smoke={s} />)}
      </div>
    </section>
  )
}
